#!/bin/sh
home/NGC_Adapter/wii-u-gc-adapter &